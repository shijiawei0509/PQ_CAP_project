import { describe, expect, it } from "vitest";
import { calibrateBaseRate } from "../code/scenarios.js";

describe("neutral S1 calibration", () => {
  it("returns the largest safe rate found by deterministic bisection", () => {
    const result = calibrateBaseRate((rate) => ({
      completedCount: rate <= 4 ? 2_000 : 1_999,
      capacityRejectedCount: rate <= 4 ? 0 : 1,
      mixedStateShare: rate <= 4 ? 0.96 : 0.94
    }), {
      lower: 0,
      upper: 8,
      iterations: 20
    });

    expect(result.rate).toBeGreaterThan(3.99);
    expect(result.rate).toBeLessThanOrEqual(4);
    expect(result.observation.completedCount).toBe(2_000);
  });

  it("fails when no rate satisfies the contract", () => {
    expect(() => calibrateBaseRate(() => ({
      completedCount: 1_999,
      capacityRejectedCount: 1,
      mixedStateShare: 0.5
    }), {
      lower: 0,
      upper: 8,
      iterations: 5
    })).toThrow(/calibration/i);
  });
});
