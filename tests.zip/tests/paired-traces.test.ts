import { describe, expect, it } from "vitest";
import {
  buildScenarioTrace,
  scenarioDefinitions
} from "../code/scenarios.js";
import type { ExperimentModel, ExperimentTask } from "../code/types.js";

const task: ExperimentTask = {
  taskId: "coding-easy",
  taskType: "coding",
  difficulty: "easy",
  promptTokens: 100,
  maxOutputTokens: 100
};
const model: ExperimentModel = {
  id: "model-a",
  baseTtftMs: 1_000,
  basePricePerMillion: 1,
  eta: 1,
  normalCapacity: 10_000,
  hardCapacity: 20_000,
  quality: {
    coding: 0.9,
    math: 0.9,
    reasoning: 0.9,
    writing: 0.9,
    translation: 0.9,
    "general-qa": 0.9
  }
};

describe("paired scenario traces", () => {
  it("is deterministic and includes paired base TTFT samples", () => {
    const left = buildScenarioTrace({
      definition: scenarioDefinitions(2, 11, 20).S1,
      tasks: [task],
      models: [model]
    });
    const right = buildScenarioTrace({
      definition: scenarioDefinitions(2, 11, 20).S1,
      tasks: [task],
      models: [model]
    });

    expect(right).toEqual(left);
    expect(left).toHaveLength(20);
    expect(left.every((request) => request.baseTtftByModel["model-a"] > 0)).toBe(true);
  });

  it("derives S2 and S3 only from the frozen S1 rate", () => {
    const definitions = scenarioDefinitions(2, 11, 20);
    expect(definitions.S2.arrivalRatePerSecond).toBe(3);
    expect(definitions.S3.burst).toEqual({
      startFraction: 0.4,
      endFraction: 0.6,
      taskTypes: ["coding", "math"],
      multiplier: 3
    });
  });
});
