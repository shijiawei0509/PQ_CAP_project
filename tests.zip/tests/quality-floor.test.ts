import { describe, expect, it } from "vitest";
import {
  eligibleModels,
  freezeQualityThresholds,
  loadFrozenProfile
} from "../code/model-profile.js";

describe("frozen quality thresholds", () => {
  it("uses the complete frozen pool exactly once", () => {
    const { models } = loadFrozenProfile();
    const thresholds = freezeQualityThresholds(models);

    expect(thresholds.coding).toBeCloseTo(0.83, 12);
    expect(thresholds.math).toBeCloseTo(0.89515, 12);
    expect(thresholds.reasoning).toBeCloseTo(0.83, 12);
    expect(thresholds.writing).toBeCloseTo(0.83, 12);
    expect(thresholds.translation).toBeCloseTo(0.83, 12);
    expect(thresholds["general-qa"]).toBeCloseTo(0.86, 12);
    expect(eligibleModels(models, "coding", thresholds)).toHaveLength(3);
    expect(eligibleModels(models, "math", thresholds)).toHaveLength(4);
    expect(eligibleModels(models, "general-qa", thresholds)).toHaveLength(5);
  });
});
