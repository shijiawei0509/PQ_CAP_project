import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { sha256File } from "../code/export.js";
import { executeExperiment } from "../code/run.js";
import { validateExperiment } from "../code/validate.js";

describe("small end-to-end experiment", () => {
  it("writes deterministic paired data without figures", () => {
    const left = fs.mkdtempSync(path.join(os.tmpdir(), "quality-first-left-"));
    const right = fs.mkdtempSync(path.join(os.tmpdir(), "quality-first-right-"));
    for (const outputRoot of [left, right]) {
      executeExperiment({
        outputRoot,
        requestCount: 20,
        seeds: [11],
        methodIds: ["ours", "cheapest-eligible"],
        lambda0Override: 0.1
      });
    }

    expect(sha256File(path.join(left, "output", "per-request.csv.gz"))).toBe(
      sha256File(path.join(right, "output", "per-request.csv.gz"))
    );
    expect(sha256File(path.join(left, "output", "aggregate.csv"))).toBe(
      sha256File(path.join(right, "output", "aggregate.csv"))
    );
    expect(fs.readdirSync(path.join(left, "output"))).not.toContain("figures");
    expect(validateExperiment(left).requestRowCount).toBe(120);
  });
});
