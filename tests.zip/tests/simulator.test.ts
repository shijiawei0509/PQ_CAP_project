import { describe, expect, it } from "vitest";
import type { TaskType } from "../../../../server/types.js";
import { createRouters } from "../code/routers.js";
import { simulate } from "../code/simulator.js";
import type {
  ExperimentModel,
  ExperimentRequest,
  ScenarioDefinition
} from "../code/types.js";

const quality = Object.fromEntries([
  "coding",
  "math",
  "reasoning",
  "writing",
  "translation",
  "general-qa"
].map((taskType) => [taskType, 0.9])) as Record<TaskType, number>;

const models: ExperimentModel[] = [{
  id: "model-a",
  baseTtftMs: 100,
  basePricePerMillion: 1,
  eta: 1,
  normalCapacity: 1_000,
  hardCapacity: 2_000,
  quality
}];
const thresholds = { ...quality, coding: 0.88 };
const scenario: ScenarioDefinition = {
  id: "S1",
  seed: 11,
  requestCount: 2,
  arrivalRatePerSecond: 1
};

function request(id: string, arrivalTimeMs: number): ExperimentRequest {
  return {
    requestId: id,
    taskId: "coding",
    taskType: "coding",
    difficulty: "easy",
    arrivalTimeMs,
    promptTokens: 100,
    maxOutputTokens: 100,
    baseTtftByModel: { "model-a": 100 }
  };
}

describe("threshold event simulator", () => {
  it("reserves on admission and releases exactly at completion", () => {
    const result = simulate({
      scenario,
      requests: [request("r1", 0), request("r2", 1_000)],
      models,
      thresholds,
      loadClasses: { "model-a": "low" },
      router: createRouters("model-a")[0],
      requestTimeoutMs: 10_000
    });

    expect(result.requests.map((row) => row.status)).toEqual(["completed", "completed"]);
    expect(result.finalExperimentLoads).toEqual({ "model-a": 0 });
    expect(result.validation.finalLoadsZero).toBe(true);
    expect(result.giniEvents.reduce(
      (sum, event) => sum + event.gini * (event.endTimeMs - event.startTimeMs),
      0
    )).toBeCloseTo(result.timeWeightedLoadGini * 1_000);
  });

  it("preserves a hard-capacity rejection with null latency", () => {
    const result = simulate({
      scenario: { ...scenario, requestCount: 1 },
      requests: [{
        ...request("r1", 0),
        promptTokens: 400,
        maxOutputTokens: 400
      }],
      models,
      thresholds,
      loadClasses: { "model-a": "congested" },
      router: createRouters("model-a")[0],
      requestTimeoutMs: 10_000
    });

    expect(result.requests[0]).toMatchObject({
      status: "rejected-capacity",
      modelId: null,
      queueWaitMs: null,
      endToEndTtftMs: null
    });
  });
});
