import { describe, expect, it } from "vitest";
import { TASK_TYPES } from "../../../../server/types.js";
import {
  eligibleModels,
  freezeQualityThresholds,
  loadFrozenProfile
} from "../code/model-profile.js";
import {
  anchorLoad,
  buildLoadAssignments
} from "../code/load-traces.js";
import { SEEDS } from "../code/types.js";

describe("background load rotation", () => {
  it("gives every task all three load classes in every seed", () => {
    const { models } = loadFrozenProfile();
    const thresholds = freezeQualityThresholds(models);
    const assignments = buildLoadAssignments(models, thresholds, SEEDS);

    for (const seed of SEEDS) {
      for (const taskType of TASK_TYPES) {
        const ids = eligibleModels(models, taskType, thresholds).map((model) => model.id);
        expect(new Set(ids.map((id) => assignments[seed][id])).size).toBe(3);
      }
    }
  });

  it("rotates every three-candidate model twice through every class", () => {
    const { models } = loadFrozenProfile();
    const thresholds = freezeQualityThresholds(models);
    const assignments = buildLoadAssignments(models, thresholds, SEEDS);
    const ids = eligibleModels(models, "coding", thresholds).map((model) => model.id);

    for (const id of ids) {
      const classes = SEEDS.map((seed) => assignments[seed][id]);
      expect(classes.filter((value) => value === "low")).toHaveLength(2);
      expect(classes.filter((value) => value === "near")).toHaveLength(2);
      expect(classes.filter((value) => value === "congested")).toHaveLength(2);
    }
  });

  it("uses the approved load anchors", () => {
    const { models } = loadFrozenProfile();
    const model = models[0];
    expect(anchorLoad(model, "low")).toBeCloseTo(0.4 * model.normalCapacity);
    expect(anchorLoad(model, "near")).toBeCloseTo(0.9 * model.normalCapacity);
    expect(anchorLoad(model, "congested")).toBeCloseTo(
      model.normalCapacity + 0.4 * (model.hardCapacity - model.normalCapacity)
    );
  });
});
