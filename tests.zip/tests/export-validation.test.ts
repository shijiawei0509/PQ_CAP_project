import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  assertNoFigureArtifacts,
  readGzipCsv,
  writeGzipCsv
} from "../code/export.js";

describe("stable experiment export", () => {
  it("round-trips UTF-8 CSV through gzip", () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), "quality-first-export-"));
    const file = path.join(directory, "rows.csv.gz");
    const rows = [
      { id: "a", value: 1, note: "含逗号,与引号\"" },
      { id: "b", value: 2, note: "" }
    ];

    writeGzipCsv(file, rows, ["id", "value", "note"]);
    expect(readGzipCsv(file)).toEqual([
      { id: "a", value: "1", note: "含逗号,与引号\"" },
      { id: "b", value: "2", note: "" }
    ]);
  });

  it("rejects figure artifacts", () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), "quality-first-figures-"));
    fs.writeFileSync(path.join(directory, "unexpected.png"), "x");
    expect(() => assertNoFigureArtifacts(directory)).toThrow(/figure/i);
  });
});
