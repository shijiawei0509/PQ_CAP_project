import { describe, expect, it } from "vitest";
import type { TaskType } from "../../../../server/types.js";
import {
  buildCandidates,
  createBalancedReferenceRouter,
  createRouters,
  selectCheapest,
  selectOurs
} from "../code/routers.js";
import type {
  ExperimentModel,
  ExperimentRequest,
  RouteCandidate
} from "../code/types.js";

const quality = Object.fromEntries([
  "coding",
  "math",
  "reasoning",
  "writing",
  "translation",
  "general-qa"
].map((taskType) => [taskType, 0.9])) as Record<TaskType, number>;

function model(id: string, price: number): ExperimentModel {
  return {
    id,
    baseTtftMs: 100,
    basePricePerMillion: price,
    eta: 1,
    normalCapacity: 1_000,
    hardCapacity: 2_000,
    quality: { ...quality }
  };
}

function candidate(
  id: string,
  values: Partial<RouteCandidate>
): RouteCandidate {
  const fixtureModel = model(id, values.model?.basePricePerMillion ?? 1);
  return {
    quality: 0.9,
    reservedLoad: 10,
    loadBefore: 0,
    postLoad: 500,
    baseTtftMs: 100,
    queueWaitMs: 0,
    endToEndTtftMs: 100,
    postAdmissionGini: 0.2,
    ...values,
    model: values.model ?? fixtureModel
  };
}

describe("ours router", () => {
  it("orders by congestion, queue, base TTFT, then post-admission Gini", () => {
    expect(selectOurs([
      candidate("congested", { postLoad: 1_100, queueWaitMs: 1 }),
      candidate("normal", { postLoad: 900, queueWaitMs: 0, baseTtftMs: 200 })
    ])?.model.id).toBe("normal");

    expect(selectOurs([
      candidate("queue-high", { postLoad: 1_100, queueWaitMs: 50 }),
      candidate("queue-low", { postLoad: 1_100, queueWaitMs: 10 })
    ])?.model.id).toBe("queue-low");

    expect(selectOurs([
      candidate("base-high", { baseTtftMs: 200 }),
      candidate("base-low", { baseTtftMs: 100 })
    ])?.model.id).toBe("base-low");

    expect(selectOurs([
      candidate("gini-high", { postAdmissionGini: 0.3 }),
      candidate("gini-low", { postAdmissionGini: 0.1 })
    ])?.model.id).toBe("gini-low");
  });
});

describe("shared eligibility and baselines", () => {
  const models = [model("cheap-congested", 1), model("expensive-normal", 2)];
  const request: ExperimentRequest = {
    requestId: "r1",
    taskId: "t1",
    taskType: "coding",
    difficulty: "easy",
    arrivalTimeMs: 0,
    promptTokens: 10,
    maxOutputTokens: 10,
    baseTtftByModel: {
      "cheap-congested": 100,
      "expensive-normal": 100
    }
  };
  const thresholds = { ...quality, coding: 0.88 };
  const input = {
    request,
    models,
    thresholds,
    totalLoads: {
      "cheap-congested": 1_100,
      "expensive-normal": 100
    },
    recentTtfts: {
      "cheap-congested": [],
      "expensive-normal": []
    }
  };

  it("cheapest does not filter a soft-congested eligible model", () => {
    const candidates = buildCandidates(input);
    expect(selectCheapest(candidates)?.model.id).toBe("cheap-congested");
  });

  it("gives every request-level router the same eligible IDs", () => {
    const candidates = buildCandidates(input);
    const ids = candidates.map((value) => value.model.id);
    const routers = createRouters("expensive-normal")
      .filter((router) => router.id !== "best-single");
    for (const router of routers) {
      expect(router.select({ ...input, candidates }).eligibleIds).toEqual(ids);
    }
  });

  it("cycles deterministically for neutral calibration", () => {
    const router = createBalancedReferenceRouter();
    const candidates = buildCandidates(input);
    expect(router.select({ ...input, candidates }).modelId).toBe("cheap-congested");
    expect(router.select({ ...input, candidates }).modelId).toBe("expensive-normal");
    expect(router.select({ ...input, candidates }).modelId).toBe("cheap-congested");
  });
});
