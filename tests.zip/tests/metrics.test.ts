import { describe, expect, it } from "vitest";
import {
  aggregatePerSeed,
  evaluateMechanism,
  perSeedMetrics,
  type PerSeedMetrics
} from "../code/metrics.js";
import type { RequestResult, SimulationResult } from "../code/simulator.js";

function request(
  requestId: string,
  status: RequestResult["status"],
  values: Partial<RequestResult> = {}
): RequestResult {
  return {
    scenario: "S2",
    seed: 11,
    method: "ours",
    requestId,
    taskId: "coding",
    taskType: "coding",
    status,
    modelId: status === "rejected-capacity" ? null : "model-a",
    arrivalTimeMs: 0,
    completionTimeMs: 100,
    promptTokens: 10,
    maxOutputTokens: 10,
    reservedLoad: status === "rejected-capacity" ? null : 20,
    loadBefore: status === "rejected-capacity" ? null : 100,
    postLoad: status === "rejected-capacity" ? null : 120,
    normalCapacity: status === "rejected-capacity" ? null : 1_000,
    hardCapacity: status === "rejected-capacity" ? null : 2_000,
    baseTtftMs: status === "completed" ? 100 : null,
    queueWaitMs: status === "completed" ? 0 : null,
    endToEndTtftMs: status === "completed" ? 100 : null,
    quality: status === "completed" ? 0.9 : null,
    nonCongested: status === "completed" ? true : null,
    reason: "fixture",
    ...values
  };
}

describe("six approved metrics", () => {
  it("uses completed, routed, and all-request denominators correctly", () => {
    const result: SimulationResult = {
      requests: [
        request("r1", "completed"),
        request("r2", "completed", {
          queueWaitMs: 100,
          endToEndTtftMs: 200,
          quality: 0.8,
          nonCongested: false
        }),
        request("r3", "simulated-timeout", {
          queueWaitMs: 50,
          quality: 0.9,
          nonCongested: true
        }),
        request("r4", "rejected-capacity")
      ],
      giniEvents: [],
      timeWeightedLoadGini: 0.25,
      mixedStateShare: 0.5,
      capacityRejectedCount: 1,
      finalExperimentLoads: { "model-a": 0 },
      validation: { finalLoadsZero: true, capacityInvariant: true }
    };
    const metrics = perSeedMetrics(result);

    expect(metrics.averageQuality).toBeCloseTo(0.85);
    expect(metrics.p95EndToEndTtftMs).toBe(200);
    expect(metrics.p95QueueWaitMs).toBe(100);
    expect(metrics.loadGini).toBe(0.25);
    expect(metrics.completionRate).toBe(0.5);
    expect(metrics.nonCongestedRate).toBeCloseTo(2 / 3);
  });
});

function row(
  method: PerSeedMetrics["method"],
  seed: number,
  values: Partial<PerSeedMetrics>
): PerSeedMetrics {
  return {
    scenario: "S2",
    seed,
    method,
    requestCount: 2_000,
    completedCount: 2_000,
    routedCount: 2_000,
    averageQuality: 0.9,
    p95EndToEndTtftMs: 100,
    p95QueueWaitMs: 10,
    loadGini: 0.2,
    completionRate: 1,
    nonCongestedRate: 0.9,
    ...values
  };
}

describe("aggregation and mechanism gate", () => {
  it("reports a 95% t interval over six seeds", () => {
    const rows = [11, 23, 37, 53, 71, 89].map((seed, index) =>
      row("ours", seed, { p95QueueWaitMs: index + 1 })
    );
    const aggregate = aggregatePerSeed(rows)[0];
    expect(aggregate.seedCount).toBe(6);
    expect(aggregate.p95QueueWaitMsMean).toBe(3.5);
    expect(aggregate.p95QueueWaitMsCiHigh).toBeGreaterThan(3.5);
  });

  it("does not require Gini to be best", () => {
    const rows = [11, 23, 37, 53, 71, 89].flatMap((seed) => [
      row("ours", seed, {
        nonCongestedRate: 1,
        p95QueueWaitMs: 0,
        loadGini: 0.4
      }),
      row("least-loaded-eligible", seed, {
        nonCongestedRate: 0.8,
        p95QueueWaitMs: 20,
        loadGini: 0.1
      })
    ]);
    expect(evaluateMechanism(rows).supported).toBe(true);
  });
});
