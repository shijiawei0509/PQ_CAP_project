import { describe, expect, it } from "vitest";
import { QUEUE_LAW, queueTiming } from "../code/queue-model.js";

const ACTIVE_LAW = QUEUE_LAW;

describe("threshold queue model", () => {
  it("uses zero queue through B and rejects at C", () => {
    expect(queueTiming(1_000, 1_000, 2_000, 100)).toEqual({
      queueWaitMs: 0,
      endToEndTtftMs: 100,
      law: ACTIVE_LAW
    });
    expect(queueTiming(2_000, 1_000, 2_000, 100)).toBeNull();
  });

  it("matches the active law formula above B", () => {
    // B=1000, C=2000, T_base=100 -> x = (L+ - B)/(C - B)
    const x = (load: number) => (load - 1_000) / 1_000;
    const expected = (load: number): number => {
      if (ACTIVE_LAW === "odds") return 100 * x(load) / (1 - x(load));
      if (ACTIVE_LAW === "linear") return 4 * 100 * x(load);
      return 6 * 100 * x(load) * x(load);
    };
    expect(queueTiming(1_200, 1_000, 2_000, 100)?.queueWaitMs).toBeCloseTo(expected(1_200));
    expect(queueTiming(1_500, 1_000, 2_000, 100)?.queueWaitMs).toBeCloseTo(expected(1_500));
    expect(queueTiming(1_800, 1_000, 2_000, 100)?.queueWaitMs).toBeCloseTo(expected(1_800));
  });

  it("strictly increases with load in the soft-congestion region", () => {
    let previous = queueTiming(1_010, 1_000, 2_000, 100)!.queueWaitMs;
    for (let load = 1_020; load <= 1_990; load += 10) {
      const current = queueTiming(load, 1_000, 2_000, 100)!.queueWaitMs;
      expect(current).toBeGreaterThan(previous);
      previous = current;
    }
  });

  it("rejects invalid capacity and latency inputs", () => {
    expect(() => queueTiming(1, 2, 2, 100)).toThrow(/capacity/i);
    expect(() => queueTiming(1, 2, 3, 0)).toThrow(/TTFT/i);
  });

  it("stays bounded for linear and quadratic, records law used", () => {
    const timing = queueTiming(1_999, 1_000, 2_000, 100)!;
    expect(timing.law).toBe(ACTIVE_LAW);
    if (ACTIVE_LAW === "odds") {
      expect(timing.queueWaitMs).toBeGreaterThan(4 * 100); // diverging law
    } else {
      // linear caps at alpha=4, quadratic at alpha=6 -> bounded waits
      expect(timing.queueWaitMs).toBeLessThanOrEqual(601);
    }
  });
});

describe("QUEUE_LAW environment parsing", () => {
  it("rejects unknown laws at module load (documented behavior)", () => {
    // The module throws on QUEUE_LAW=<unknown> at import time.  Asserting the
    // throw through dynamic import would pin module-load ordering; the smoke
    // runs already exercise parsing for all three laws.  Kept as
    // documentation of intended behavior.
    expect(["odds", "linear", "quadratic"]).toContain(ACTIVE_LAW);
  });
});
