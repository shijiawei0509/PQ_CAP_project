import { describe, expect, it } from "vitest";
import {
  METHODS,
  QUALITY_EPSILON,
  REQUEST_COUNT,
  SEEDS
} from "../code/types.js";

describe("frozen experiment constants", () => {
  it("matches the approved design", () => {
    expect(SEEDS).toEqual([11, 23, 37, 53, 71, 89]);
    expect(REQUEST_COUNT).toBe(2_000);
    expect(QUALITY_EPSILON).toBe(0.02);
    expect(METHODS).toEqual([
      "ours",
      "best-single",
      "cheapest-eligible",
      "irt-router-style",
      "mixllm-style",
      "openrouter-performance-style",
      "least-loaded-eligible"
    ]);
  });
});
